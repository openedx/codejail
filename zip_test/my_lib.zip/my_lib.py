def funk():
    return 'hello world ᚻ'
