def funk():
    return 'hello world'
